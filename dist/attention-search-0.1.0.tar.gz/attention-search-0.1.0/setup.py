# -*- coding: utf-8 -*-
from setuptools import setup

package_dir = \
{'': 'src'}

modules = \
['attention_search']
install_requires = \
['numpy<1.19.0']

setup_kwargs = {
    'name': 'attention-search',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'crodriguez1a',
    'author_email': 'crodriguez1a@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'package_dir': package_dir,
    'py_modules': modules,
    'install_requires': install_requires,
    'python_requires': '>=3.7.5,<4.0.0',
}


setup(**setup_kwargs)
